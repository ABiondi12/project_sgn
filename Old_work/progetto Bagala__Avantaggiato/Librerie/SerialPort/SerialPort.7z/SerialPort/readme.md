SerialPort is a library from [Bill Greiman�s library](https://github.com/greiman/SerialPort).

OpenLog currently uses the [February 16 2014](https://github.com/greiman/SerialPort/commit/9886a4dc8dc5acc37b4fc36e09186b4dabee9fa4) version.

For more information about installing Arduino libraries see the [SparkFun Learn tutorial](https://learn.sparkfun.com/tutorials/installing-an-arduino-library).